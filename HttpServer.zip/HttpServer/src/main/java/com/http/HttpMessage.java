package com.http;

public abstract class HttpMessage {
}
