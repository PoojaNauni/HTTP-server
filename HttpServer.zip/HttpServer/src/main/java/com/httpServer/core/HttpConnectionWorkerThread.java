package com.httpServer.core;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;


public class HttpConnectionWorkerThread extends Thread{

    private final static Logger LOGGER = (Logger) LoggerFactory.getLogger(HttpConnectionWorkerThread.class);

    private Socket socket;

    public HttpConnectionWorkerThread(Socket socket)
    {
        this.socket = socket;
    }

    @Override
    public void run() {
        InputStream inputStream = null;
        OutputStream outputStream = null;
        try {
             inputStream = socket.getInputStream();
             outputStream = socket.getOutputStream();

            String html = "<html>" +
                        "<head>" +
                            "<tile>Multithreaded Java HTTP Server</tile>" +
                        "</head>"+
                        "<body>"+
                            "<h1><center><font size = '50' face = 'ALGERIAN'>Hello!!</font></center></h1>"+
                            "<p><center><font size = '30' face = 'STELLAR' color = 'blue'>This page is served using my Multithreaded HTTP Server using Java.</font></center></p>"+
                            "<h3><center><font size = '50' face = 'ALGERIAN'>Thank you.</font></center></h3>" +
                        "</body>" +
                    "</html>";

            final String CRLF = "\n\r"; // 13, 10

            String response =
                    "HTTP/1.1 200 OK" + CRLF + // Status Line : HTTP VERSION RESPONSE_CODE RESPONSE_MESSAGE
                            "Content - Length : " + html.getBytes().length + CRLF + // HEADER
                            CRLF +
                            html +
                            CRLF + CRLF;

            outputStream.write(response.getBytes());

            LOGGER.info(" * Connection Processing Finished.");
        }

        catch (IOException e)
        {
            LOGGER.error("Problem in Communication ",e);
        }
        finally
        {
            if(inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                }
            }
            if(outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                }
            }
            if (socket != null) {
                try {
                    socket.close();
                } catch (IOException e) {
                }
            }

        }
    }
}
